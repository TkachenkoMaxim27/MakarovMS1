﻿using ClassLibrary1;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Servers servers = Servers.Instance;

         
            Console.WriteLine(servers.AddServer("http://example.com"));  
            Console.WriteLine(servers.AddServer("https://example.org"));  
            Console.WriteLine(servers.AddServer("ftp://example.net"));    

         
            Console.WriteLine(servers.AddServer("http://example.com"));  

            
            Console.WriteLine("HTTP servers:");
            foreach (var server in servers.GetHttpServers())
            {
                Console.WriteLine(server);
            }

            Console.WriteLine("HTTPS servers:");
            foreach (var server in servers.GetHttpsServers())
            {
                Console.WriteLine(server);
            }
        }
    }
}